﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDES_Implementor
{
    class GDESRule
    {
        public Guid ID;
        public Guid InputFact1;
        public Guid InputFact2;
        public float IF1Weight;
        public float IF2Weight;
        public Guid OutputFact;
        public bool AlreadyRun;
        public string Description;
    }
}
