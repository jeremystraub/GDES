﻿
namespace GDES_Implementor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbCommands = new System.Windows.Forms.TextBox();
            this.btnRunCommands = new System.Windows.Forms.Button();
            this.btnLoadCommandText = new System.Windows.Forms.Button();
            this.btnSaveCommandText = new System.Windows.Forms.Button();
            this.tbStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbCommands
            // 
            this.tbCommands.Location = new System.Drawing.Point(13, 13);
            this.tbCommands.Multiline = true;
            this.tbCommands.Name = "tbCommands";
            this.tbCommands.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbCommands.Size = new System.Drawing.Size(1392, 637);
            this.tbCommands.TabIndex = 0;
            // 
            // btnRunCommands
            // 
            this.btnRunCommands.Location = new System.Drawing.Point(1105, 657);
            this.btnRunCommands.Name = "btnRunCommands";
            this.btnRunCommands.Size = new System.Drawing.Size(300, 54);
            this.btnRunCommands.TabIndex = 1;
            this.btnRunCommands.Text = "&Run Commands";
            this.btnRunCommands.UseVisualStyleBackColor = true;
            this.btnRunCommands.Click += new System.EventHandler(this.btnRunCommands_Click);
            // 
            // btnLoadCommandText
            // 
            this.btnLoadCommandText.Location = new System.Drawing.Point(12, 657);
            this.btnLoadCommandText.Name = "btnLoadCommandText";
            this.btnLoadCommandText.Size = new System.Drawing.Size(300, 54);
            this.btnLoadCommandText.TabIndex = 2;
            this.btnLoadCommandText.Text = "&Load Command Text";
            this.btnLoadCommandText.UseVisualStyleBackColor = true;
            this.btnLoadCommandText.Click += new System.EventHandler(this.btnLoadCommandText_Click);
            // 
            // btnSaveCommandText
            // 
            this.btnSaveCommandText.Location = new System.Drawing.Point(318, 657);
            this.btnSaveCommandText.Name = "btnSaveCommandText";
            this.btnSaveCommandText.Size = new System.Drawing.Size(300, 54);
            this.btnSaveCommandText.TabIndex = 2;
            this.btnSaveCommandText.Text = "&Save Command Text";
            this.btnSaveCommandText.UseVisualStyleBackColor = true;
            this.btnSaveCommandText.Click += new System.EventHandler(this.btnSaveCommandText_Click);
            // 
            // tbStatus
            // 
            this.tbStatus.AutoSize = true;
            this.tbStatus.Location = new System.Drawing.Point(652, 672);
            this.tbStatus.Name = "tbStatus";
            this.tbStatus.Size = new System.Drawing.Size(0, 25);
            this.tbStatus.TabIndex = 3;
            this.tbStatus.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1417, 723);
            this.Controls.Add(this.tbStatus);
            this.Controls.Add(this.btnSaveCommandText);
            this.Controls.Add(this.btnLoadCommandText);
            this.Controls.Add(this.btnRunCommands);
            this.Controls.Add(this.tbCommands);
            this.Name = "Form1";
            this.Text = "GDES Implementor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbCommands;
        private System.Windows.Forms.Button btnRunCommands;
        private System.Windows.Forms.Button btnLoadCommandText;
        private System.Windows.Forms.Button btnSaveCommandText;
        private System.Windows.Forms.Label tbStatus;
    }
}

