﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDES_Implementor
{
    class Contributions
    {
        public Guid ContributionOf;
        public Guid ContributionTo;
        public float ContributionLevel;
    }
}
