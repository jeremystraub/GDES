﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDES_Implementor
{
    class ParseCommands
    {
        GDES ES;
        public ParseCommands(GDES ESInput)
        {
            ES = ESInput;
        }
        public ParseResult ParseFact(string InputText)
        {
            bool FormatError = false;

            int FactNumber = 0;
            Guid FactID = Guid.Empty;
            decimal FactValue = 0;
            string Description = "";

            if (InputText.Length > 52)
            {
                if (InputText[0] != 'F')
                    FormatError = true;

                if (!int.TryParse(InputText.Substring(1, 4), out FactNumber))
                    FormatError = true;

                if (InputText[5] != ':')
                    FormatError = true;

                if (!Guid.TryParse(InputText.Substring(6, 38), out FactID))
                    FormatError = true;

                if (InputText[44] != '=')
                    FormatError = true;

                if (!decimal.TryParse(InputText.Substring(45, 7), out FactValue))
                    FormatError = true;

                if (InputText[52] != ':')
                    FormatError = true;

                Description = InputText.Substring(53);
            }
            else
                FormatError = true;

            ParseResult ret = new ParseResult();
            if (FormatError)
            {
                ret.ErrorNumber = 100;
                ret.ErrorText = "Format Error Detected";
            }
            else
            {
                ret.ErrorNumber = 0;
                ret.ErrorText = "";
                ES.MakeFact(FactID, FactNumber, (float)FactValue, Description);
            }

            return ret;
        }

        public ParseResult ParseRule(string InputText)
        {
            int RuleNumber=0;
            Guid RuleID = Guid.Empty, Fact1ID = Guid.Empty, Fact2ID = Guid.Empty, Fact3ID = Guid.Empty;
            decimal Fact1Weight = 0, Fact2Weight = 0;

            string Description = "";

            bool FormatError = false;
            if (InputText.Length > 174)
            {
                if (InputText[0] != 'R')
                    FormatError = true;

                if (!int.TryParse(InputText.Substring(1, 4), out RuleNumber))
                    FormatError = true;

                if (InputText[5] != ':')
                    FormatError = true;

                if (!Guid.TryParse(InputText.Substring(6, 38), out RuleID))
                    FormatError = true;

                if (InputText[44] != ':')
                    FormatError = true;

                if (!Guid.TryParse(InputText.Substring(45, 38), out Fact1ID))
                    FormatError = true;

                if (InputText[83] != '=')
                    FormatError = true;

                if (!decimal.TryParse(InputText.Substring(84, 5), out Fact1Weight))
                    FormatError = true;

                if (InputText[89] != '+')
                    FormatError = true;

                if (!Guid.TryParse(InputText.Substring(90, 38), out Fact2ID))
                    FormatError = true;

                if (InputText[128] != '=')
                    FormatError = true;

                if (!decimal.TryParse(InputText.Substring(129, 5), out Fact2Weight))
                    FormatError = true;

                if (!(InputText.Substring(134, 2) == ">>"))
                    FormatError = true;

                if (!Guid.TryParse(InputText.Substring(136, 38), out Fact3ID))
                    FormatError = true;

                if (InputText[174] != ':')
                    FormatError = true;

                Description = InputText.Substring(175);
            }
            else
                FormatError = true;

            ParseResult ret = new ParseResult();
            if (FormatError)
            {
                ret.ErrorNumber = 100;
                ret.ErrorText = "Format Error Detected";
            }
            else
            {
                ret.ErrorNumber = 0;
                ret.ErrorText = "";
                ES.MakeRule(RuleID, RuleNumber, Fact1ID, Fact2ID, (float)Fact1Weight, (float)Fact2Weight, Fact3ID, Description);
            }

            return ret;
        }

        public ParseResult ParseTrain(string InputText)
        {
            int iterations = 0;
            decimal velocity = 0;
            Guid Fact1ID = Guid.Empty, Fact2ID = Guid.Empty;
            decimal Fact1Value = 0, Fact2Value = 0;

            bool FormatError = false;

            if (InputText.Length > 105)
            {
                if (InputText.Substring(0, 2) != "TR")
                    FormatError = true;

                if (InputText[2] != ':')
                    FormatError = true;

                if (!Guid.TryParse(InputText.Substring(3, 38), out Fact1ID))
                    FormatError = true;

                if (InputText[41] != '=')
                    FormatError = true;

                if (!decimal.TryParse(InputText.Substring(42, 7), out Fact1Value))
                    FormatError = true;

                if (InputText[49] != '>')
                    FormatError = true;

                if (!int.TryParse(InputText.Substring(50, 4), out iterations))
                    FormatError = true;

                if (InputText[54] != ':')
                    FormatError = true;

                if (!decimal.TryParse(InputText.Substring(55, 4), out velocity))
                    FormatError = true;

                if (InputText[59] != '>')
                    FormatError = true;

                if (!Guid.TryParse(InputText.Substring(60, 38), out Fact2ID))
                    FormatError = true;

                if (InputText[98] != '=')
                    FormatError = true;

                if (!decimal.TryParse(InputText.Substring(99, 7), out Fact2Value))
                    FormatError = true;
            }
            else
                FormatError = true;

            ParseResult ret = new ParseResult();
            if (FormatError)
            {
                ret.ErrorNumber = 100;
                ret.ErrorText = "Format Error Detected";
            }
            else
            {
                ret.ErrorNumber = 0;
                ret.ErrorText = "";
                for (int i = 0; i < iterations; i++)
                    TrainGDES.TrainES(ES, (float)velocity, Fact1ID, Fact2ID, (float)Fact1Value, (float)Fact2Value);
            }

            return ret;
        }

        public ParseResult ParsePresent(string InputText)
        {
            Guid Fact1ID = Guid.Empty, Fact2ID = Guid.Empty;
            decimal Fact1Value = 0;

            bool FormatError = false;

            if (InputText.Length > 88)
            {
                if (InputText.Substring(0, 2) != "PR")
                    FormatError = true;

                if (InputText[2] != ':')
                    FormatError = true;

                if (!Guid.TryParse(InputText.Substring(3, 38), out Fact1ID))
                    FormatError = true;

                if (InputText[41] != '=')
                    FormatError = true;

                if (!decimal.TryParse(InputText.Substring(42, 7), out Fact1Value))
                    FormatError = true;

                if (InputText.Substring(49, 2) != ">>")
                    FormatError = true;

                if (!Guid.TryParse(InputText.Substring(51, 38), out Fact2ID))
                    FormatError = true;
            }
            else
                FormatError = true;

            ParseResult ret = new ParseResult();
            if (FormatError)
            {
                ret.ErrorNumber = 100;
                ret.ErrorText = "Format Error Detected";
            }
            else
            {
                ret.ErrorNumber = 0;
                ret.ErrorText = "";
                GDESResult res = ES.RunES(Fact1ID, Fact2ID, (float)Fact1Value);
                ret.Result = res.factvalue;
                ret.ProcessingTime = res.timespent;
            }

            return ret;
        }

        public ParseResult ParseSetFact(string InputText)
        {
            Guid Fact1ID = Guid.Empty;
            decimal Fact1Value = 0;

            bool FormatError = false;

            if (InputText.Length > 48)
            {
                if (InputText.Substring(0, 2) != "SF")
                    FormatError = true;

                if (InputText[2] != ':')
                    FormatError = true;

                if (!Guid.TryParse(InputText.Substring(3, 38), out Fact1ID))
                    FormatError = true;

                if (InputText[41] != '=')
                    FormatError = true;

                if (!decimal.TryParse(InputText.Substring(42, 7), out Fact1Value))
                    FormatError = true;
            }
            else
                FormatError = true;

            ParseResult ret = new ParseResult();
            if (FormatError)
            {
                ret.ErrorNumber = 100;
                ret.ErrorText = "Format Error Detected";
            }
            else
            {
                ret.ErrorNumber = 0;
                ret.ErrorText = "";
                ES.SetFactValue(Fact1ID, (float)Fact1Value);
            }

            return ret;
        }

        public ParseResult ParseQueryFact(string InputText)
        {
            Guid FactID = Guid.Empty;

            bool FormatError = false;

            if (InputText.Length > 40)
            {
                if (InputText.Substring(0, 2) != "QF")
                    FormatError = true;

                if (InputText[2] != ':')
                    FormatError = true;

                if (!Guid.TryParse(InputText.Substring(3, 38), out FactID))
                    FormatError = true;
            }
            else
                FormatError = true;

            ParseResult ret = new ParseResult();
            if (FormatError)
            {
                ret.ErrorNumber = 100;
                ret.ErrorText = "Format Error Detected";
            }
            else
            {
                ret.ErrorNumber = 0;
                ret.ErrorText = "";
                ret.Result = ES.GetFactValue(FactID);
                ret.ProcessingTime = -1;
            }

            return ret;
        }
    }
}
