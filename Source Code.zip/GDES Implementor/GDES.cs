﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDES_Implementor
{
    class GDES
    {
        List<GDESFact> facts;
        List<GDESRule> rules;
        List<Contributions> contributions;

        public void SetFactValue(Guid ID, float Value)
        {
            if (facts.Exists(x => x.ID == ID))
                facts.Find(x => x.ID == ID).Value = Value;
        }

        public float GetFactValue(Guid ID)
        {
            if (facts.Exists(x => x.ID == ID))
                return facts.Find(x => x.ID == ID).Value;
            else
                return -1;
        }

        private void InitializeIfNot()
        {
            if (facts is null && rules is null && contributions is null)
            {
                facts = new List<GDESFact>();
                rules = new List<GDESRule>();
                contributions = new List<Contributions>();
            }
        }

        public int GetFactCount()
        {
            if (facts is null)
                return 0;
            else
                return facts.Count;
        }

        public int GetRuleCont()
        {
            if (rules is null)
                return 0;
            else
                return rules.Count;
        }

        public void MakeFact(Guid ID, int number, float value, string Description)
        {
            InitializeIfNot();

            GDESFact fact = new GDESFact();
            fact.ID = ID;
            fact.Description = "[" + number + "]" + Description;
            fact.Value = value;
            fact.OrigValue = value;
            fact.FactUsed = false;
            fact.PreTrainValue = value;

            facts.Add(fact);
        }

        public void MakeRule(Guid ID, int number, Guid InputFact1, Guid InputFact2, float InputFact1Weight, float InputFact2Weight, Guid OutputFact, string Description)
        {
            InitializeIfNot();

            GDESRule rule = new GDESRule();
            rule.ID = ID;
            rule.Description = "[" + number + "]" + Description;
            rule.InputFact1 = InputFact1;
            rule.InputFact2 = InputFact2;
            rule.IF1Weight = InputFact1Weight;
            rule.IF2Weight = InputFact2Weight;
            rule.OutputFact = OutputFact;
            rule.AlreadyRun = false;

            rules.Add(rule);
        }

        public Guid GetRandomFact()
        {
            Random rnd = new Random(Guid.NewGuid().GetHashCode());
            return facts[rnd.Next(0, facts.Count)].ID;
        }

        public void SetPreTrainValues()
        {
            foreach (GDESFact f in facts)
            {
                f.PreTrainValue = f.Value;
            }
        }

        public void ResetToPreTrainValues()
        {
            foreach (GDESFact f in facts)
            {
                f.Value = f.PreTrainValue;
            }
        }

        public void ProcessContributionsLearning(Guid StartFact, Guid EndFact, float resultdelta, float velocity)
        {
            float changeamount;
            float sumcontrib = 0;

            foreach (Contributions c in contributions)
            {
                // sum total contribution to EndFact
                if (c.ContributionTo == EndFact)
                {
                    sumcontrib = sumcontrib + c.ContributionLevel;
                }
            }

            // if sumcontrib = 0, then NaNs will result due to divide by zero occuring
            if ((sumcontrib != 0) && (!float.IsNaN(resultdelta)))
            {
                foreach (Contributions c in contributions)
                {
                    // only process contributions to end fact to prevent double-processing
                    if (c.ContributionTo == EndFact)
                    {
                        foreach (GDESRule r in rules)
                        {
                            // process all rules that contribute to the fact
                            if (r.OutputFact == c.ContributionTo || r.OutputFact == c.ContributionOf)
                            {
                                if (facts.Find(x => x.ID == r.InputFact1).Value > facts.Find(x => x.ID == r.InputFact2).Value && resultdelta > 0)
                                // increase contribution of IF1
                                {
                                    changeamount = resultdelta * (c.ContributionLevel / sumcontrib) * velocity;
                                    r.IF1Weight = r.IF1Weight + changeamount;
                                    r.IF2Weight = r.IF2Weight - changeamount;
                                }
                                else
                                // increase contribution of IF2
                                {
                                    changeamount = resultdelta * (c.ContributionLevel / sumcontrib) * velocity;
                                    r.IF1Weight = r.IF1Weight - changeamount;
                                    r.IF2Weight = r.IF2Weight + changeamount;
                                }
                            }

                            // reset to boundary if bound exceeded
                            if (r.IF1Weight > 1)
                            {
                                r.IF1Weight = 1;
                                r.IF2Weight = 0;
                            }
                            if (r.IF1Weight < 0)
                            {
                                r.IF1Weight = 0;
                                r.IF2Weight = 1;
                            }

                        }
                    }
                }
            }
        }

        public void RunContributions(Guid Of, Guid To, float Level)
        {
            List<Contributions> NewContributions = new List<Contributions>();

            if (contributions.Exists(x => x.ContributionOf == Of && x.ContributionTo == To))
            {
                // Existing contribution record
                if (contributions.Find(x => x.ContributionOf == Of && x.ContributionTo == To).ContributionLevel < Level)
                {
                    // if existing contribution level is less than current level, replace
                    contributions.Find(x => x.ContributionOf == Of && x.ContributionTo == To).ContributionLevel = Level;
                }

                foreach (Contributions cntrb in contributions)
                {
                    // Contributions to the current 'Of' will create a new record / update existing record if needed
                    if (cntrb.ContributionTo == Of)
                    {
                        if (contributions.Exists(x => x.ContributionOf == cntrb.ContributionOf && x.ContributionTo == To))
                        {
                            if ((cntrb.ContributionLevel * Level) > contributions.Find(x => x.ContributionOf == cntrb.ContributionOf && x.ContributionTo == To).ContributionLevel)
                            {
                                contributions.Find(x => x.ContributionOf == cntrb.ContributionOf && x.ContributionTo == To).ContributionLevel = cntrb.ContributionLevel * Level;
                            }
                        }
                        else
                        {
                            Contributions newcntrb = new Contributions();
                            newcntrb.ContributionOf = cntrb.ContributionOf;
                            newcntrb.ContributionTo = To;
                            newcntrb.ContributionLevel = cntrb.ContributionLevel * Level;
                            NewContributions.Add(newcntrb);
                        }
                    }
                }
            }
            else
            {
                Contributions newcntb = new Contributions();

                newcntb.ContributionOf = Of;
                newcntb.ContributionTo = To;
                newcntb.ContributionLevel = Level;

                contributions.Add(newcntb);

                foreach (Contributions cntrb in contributions)
                {
                    // Contributions to the current 'Of' will create a new record / update existing record if needed
                    if (cntrb.ContributionTo == Of)
                    {
                        if (contributions.Exists(x => x.ContributionOf == cntrb.ContributionOf && x.ContributionTo == To))
                        {
                            if ((cntrb.ContributionLevel * Level) > contributions.Find(x => x.ContributionOf == cntrb.ContributionOf && x.ContributionTo == To).ContributionLevel)
                            {
                                contributions.Find(x => x.ContributionOf == cntrb.ContributionOf && x.ContributionTo == To).ContributionLevel = cntrb.ContributionLevel * Level;
                            }
                        }
                        else
                        {
                            Contributions newcntrb = new Contributions();
                            newcntrb.ContributionOf = cntrb.ContributionOf;
                            newcntrb.ContributionTo = To;
                            newcntrb.ContributionLevel = cntrb.ContributionLevel * Level;
                            NewContributions.Add(newcntrb);
                        }
                    }
                }
            }

            foreach (Contributions c in NewContributions)
            {
                contributions.Add(c);
            }
        }

        public GDESResult RunES(Guid StartFact, Guid EndFact, float StartFactValue)
        {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            long timespent;

            GDESResult result = new GDESResult();

            foreach (GDESRule r in rules)
            {
                r.AlreadyRun = false;
            }

            facts.Find(x => x.ID == StartFact).FactUsed = true;
            facts.Find(x => x.ID == EndFact).FactUsed = true;

            sw.Start();
            facts.Find(x => x.ID == StartFact).Value = StartFactValue; 

            bool continuerun = true;
            bool changed = false;

            while (continuerun == true)
            {
                changed = false;
                foreach (GDESRule rl in rules)
                {
                    // identify all rules that are triggered
                    if ((facts.Find(x => x.ID == rl.InputFact1).Value > 0) && (facts.Find(x => x.ID == rl.InputFact2).Value > 0))
                    {
                        if (rl.AlreadyRun == false)
                        {
                            // if not already run, run rule

                            facts.Find(x => x.ID == rl.OutputFact).Value = facts.Find(x => x.ID == rl.InputFact1).Value * rl.IF1Weight + facts.Find(x => x.ID == rl.InputFact2).Value * rl.IF2Weight;

                            facts.Find(x => x.ID == rl.InputFact1).FactUsed = true;
                            facts.Find(x => x.ID == rl.InputFact2).FactUsed = true;
                            facts.Find(x => x.ID == rl.OutputFact).FactUsed = true;

                            RunContributions(rl.InputFact1, rl.OutputFact, rl.IF1Weight);
                            RunContributions(rl.InputFact2, rl.OutputFact, rl.IF2Weight);

                            rl.AlreadyRun = true;
                            changed = true;
                        }
                    }
                }

                if (changed)
                {
                    continuerun = true;
                }
                else
                {
                    continuerun = false;
                }

            }
            sw.Stop();
            timespent = sw.ElapsedTicks;

            result.timespent = timespent;
            result.factvalue = facts.Find(x => x.ID == EndFact).Value;
            return result;
        }
    }
}
