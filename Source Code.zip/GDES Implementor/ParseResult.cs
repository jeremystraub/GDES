﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDES_Implementor
{
    class ParseResult
    {
        public int ErrorNumber; // 0 means success
        public string ErrorText;
        public float Result;
        public long ProcessingTime;
    }
}
