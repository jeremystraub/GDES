﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDES_Implementor
{
    class TrainGDES
    {
        public static void TrainES(GDES TrainingES, float velocity, Guid StartFact, Guid EndFact, float StartFactValue, float TruthResult)
        {
            GDESResult TrainResult;
            float resultdelta;

            // *** Added to store pre-training values for reset after training
            TrainingES.SetPreTrainValues();

            // No truth ES for this system, target results are provided by user

            TrainResult = TrainingES.RunES(StartFact, EndFact, StartFactValue); // 0.99F was replaced with user specified value

            // *** Added to reset fact values after the training so that networks are not changed by training
            // *** Rule run status is reset at the beginning of each RunES and changes to rule weights on training ES are desired

            TrainingES.ResetToPreTrainValues();

            if (TruthResult > TrainResult.factvalue)
            {
                resultdelta = (TruthResult - TrainResult.factvalue) / TruthResult;
            }
            else
            {
                resultdelta = (TruthResult - TrainResult.factvalue) / TrainResult.factvalue;
            }

            TrainingES.ProcessContributionsLearning(StartFact, EndFact, resultdelta, velocity);
        }
    }
}
